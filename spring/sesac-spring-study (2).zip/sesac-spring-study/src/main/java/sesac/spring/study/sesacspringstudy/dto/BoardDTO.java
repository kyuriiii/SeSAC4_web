package sesac.spring.study.sesacspringstudy.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardDTO {
    private String name;
    private String content;
}
