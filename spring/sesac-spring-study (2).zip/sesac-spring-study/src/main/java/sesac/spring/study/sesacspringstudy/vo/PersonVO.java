package sesac.spring.study.sesacspringstudy.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
public class PersonVO {
    private String name;
    private String gender;
}
