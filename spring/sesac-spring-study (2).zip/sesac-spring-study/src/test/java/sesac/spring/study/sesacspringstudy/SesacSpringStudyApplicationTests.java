package sesac.spring.study.sesacspringstudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SesacSpringStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
