import { useParams, useLocation } from 'react-router-dom';

function Product() {
  const { id } = useParams();
  const location = useLocation();
  // const id2 = useParams().id;
    return (
      <div>
        <h1>{id}번 Product</h1>
        
        <ul>
            <li>hash : {location.hash}</li>
            <li>pathname : {location.pathname}</li>
            <li>search : {location.search}</li>
            <li>state : {location.state}</li>
            <li>key : {location.key}</li>
        </ul>
      </div>
    );
  }
  
  export default Product;
  