import React from "react";
import "./albumAllMode.scss";

const AlbumAllMode = () => {
  return (
    <div className="allModeWrapper">
      <div className="content">{/* <img /> */}1</div>
      <div className="content">{/* <img /> */}2</div>
      <div className="content">{/* <img /> */}</div>
      <div className="content">{/* <img /> */}</div>
      <div className="content">{/* <img /> */}</div>
      <div className="content">{/* <img /> */}</div>
      <div className="content">{/* <img /> */}</div>
      <div className="content">{/* <img /> */}</div>
      <div className="content">{/* <img /> */}</div>
    </div>
  );
};

export default AlbumAllMode;
