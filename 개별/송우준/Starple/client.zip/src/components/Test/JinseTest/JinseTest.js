import React from "react";
import "./jinseTest.scss";
import Page404 from "../../../pages/Page404/Page404";

const JinseTest = () => {
  return (
    <>
      <Page404 />
    </>
  );
};

export default JinseTest;
