// import React, { useEffect } from "react";
// // import HTML from "./"

// const StarWarp = () => {
//   var __html = require("./index.html");
//   var template = { __html: __html };
//   return <div dangerouslySetInnerHTML={template} />;
// };

// export default StarWarp;
