import React from "react";
import "./contentBoard.scss";

const ContentBoard = () => {
  return <div></div>;
};

export default ContentBoard;
