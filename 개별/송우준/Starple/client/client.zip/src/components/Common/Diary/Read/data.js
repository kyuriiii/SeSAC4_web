const data = {
  post: {
    no: 1,
    category: "2022",
    title: "게시글 제목1",
    content:
      "<p>내용1</p><p>내용2</p><p>내용3</p><p>내용4</p><p>내용5</p><p>내용1</p><p>내용2</p><p>내용3</p><p>내용4</p><p>내용5</p><p>내용1</p><p>내용2</p><p>내용3</p><p>내용4</p><p>내용5</p>",
    writer: "염시온",
    timestamp: "2022-01-01"
  },
  comment: [
    {
      writer: "송진세",
      comment: "오홍"
    },
    {
      writer: "정예현",
      comment: "그렇군"
    }
  ]
};
export default data;
