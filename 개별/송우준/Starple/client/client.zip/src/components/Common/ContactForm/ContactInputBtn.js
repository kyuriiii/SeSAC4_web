import React from "react";
import "./ContactInputBtn.scss";

export default function ContactInputBtn() {
  return (
    <div>
      <button className="ContactInputBtnBox">보내기</button>
    </div>
  );
}
