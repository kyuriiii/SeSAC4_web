import React from "react";
import "./Planet_name.scss";

const Planet_name = ({ title }) => {
  return <div className="Planet_name">{title}</div>;
};

export default Planet_name;
