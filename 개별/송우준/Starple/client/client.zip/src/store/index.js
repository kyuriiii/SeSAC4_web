import countClass from "./countClass";
import planetClass from "./planetClass";
import userClass from "./userClass";
const store = { countClass, planetClass, userClass };
export default store;
