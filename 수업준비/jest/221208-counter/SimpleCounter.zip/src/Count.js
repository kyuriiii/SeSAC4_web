function CountView({ count }) {
    return <h1>현재 숫자: {count}</h1>;
  }
  
  export default CountView;