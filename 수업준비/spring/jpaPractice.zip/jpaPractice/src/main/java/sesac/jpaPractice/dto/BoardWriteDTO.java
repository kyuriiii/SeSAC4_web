package sesac.jpaPractice.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardWriteDTO {
    private String title;
    private String content;
    private String writer;
}
