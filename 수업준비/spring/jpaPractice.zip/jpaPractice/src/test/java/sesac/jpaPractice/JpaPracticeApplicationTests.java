package sesac.jpaPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
